<?php
session_start();
if (isset($_SESSION['user_id'])) { header("Location: dashboard.php"); exit(); }
?>
<!DOCTYPE html><html><body>
<h2>Form Login</h2>
<form action="login_process.php" method="POST">
<label>Username:</label><br><input type="text" name="username" required><br><br>
<label>Password:</label><br><input type="password" name="password" required><br><br>
<button type="submit" name="login">Login</button>
</form>
</body></html>