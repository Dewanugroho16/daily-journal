<?php
include 'config/koneksi.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daily Journal</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2>Daftar Artikel</h2>

<?php
$query = mysqli_query($koneksi, "SELECT * FROM article ORDER BY tanggal DESC");

while ($data = mysqli_fetch_assoc($query)) {
?>
    <div class="card">
        <h3><?php echo $data['judul']; ?></h3>
        <p class="tanggal">
            Ditulis oleh <b><?php echo $data['username']; ?></b>
            | <?php echo $data['tanggal']; ?>
        </p>

        <img src="img/<?php echo $data['gambar']; ?>" width="200">

        <p><?php echo substr($data['isi'], 0, 150); ?>...</p>

        <a href="article.php?id=<?php echo $data['id']; ?>">Baca Selengkapnya</a>
    </div>
<?php } ?>

</body>
</html>