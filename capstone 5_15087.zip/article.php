<?php
include 'config/koneksi.php';

$id = $_GET['id'];
$query = mysqli_query($koneksi, "SELECT * FROM article WHERE id='$id'");
$data = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo $data['judul']; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2><?php echo $data['judul']; ?></h2>
<p>
    Ditulis oleh <b><?php echo $data['username']; ?></b> |
    <?php echo $data['tanggal']; ?>
</p>

<img src="img/<?php echo $data['gambar']; ?>" width="300">

<p><?php echo $data['isi']; ?></p>

<a href="index.php">← Kembali</a>

</body>
</html>