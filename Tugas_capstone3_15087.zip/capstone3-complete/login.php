<!DOCTYPE html>
<html>
<head>
<title>Form Login</title>
</head>
<body>
<h2>Form Login</h2>
<form action="proses_login.php" method="POST">
    Username:<br>
    <input type="text" name="username" required><br><br>
    Password:<br>
    <input type="password" name="password" required><br><br>
    <button type="submit">Login</button>
</form>
</body>
</html>