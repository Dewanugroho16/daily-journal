CAPSTONE 3 - FORM LOGIN (PHP)

Isi:
1. koneksi.php
2. login.php
3. proses_login.php
4. dashboard.php
5. logout.php
6. database.sql

Sudah lengkap sesuai perintah: form login + proses login + dashboard + logout + database.
Gunakan XAMPP lalu import database.sql.
