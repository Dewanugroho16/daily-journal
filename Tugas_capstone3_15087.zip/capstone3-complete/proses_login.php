<?php
session_start();
include 'koneksi.php';

$username = $_POST['username'];
$password = $_POST['password'];

$query = mysqli_query($koneksi, "SELECT * FROM user WHERE username='$username' AND password='$password'");
$data = mysqli_fetch_assoc($query);

if($data){
    $_SESSION['username'] = $data['username'];
    header("Location: dashboard.php");
} else {
    echo "Login gagal. <a href='login.php'>Coba lagi</a>";
}
?>