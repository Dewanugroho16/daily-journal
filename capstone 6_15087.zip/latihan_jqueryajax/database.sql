CREATE DATABASE db_umkm;
USE db_umkm;

CREATE TABLE umkm (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_umkm VARCHAR(100),
    pemilik VARCHAR(100),
    alamat TEXT
);

INSERT INTO umkm (nama_umkm, pemilik, alamat) VALUES
('UMKM Sari Rasa', 'Budi', 'Semarang'),
('UMKM Jaya Abadi', 'Ani', 'Semarang'),
('UMKM Makmur', 'Dewi', 'Semarang'),
('UMKM Sejahtera', 'Rudi', 'Semarang'),
('UMKM Barokah', 'Siti', 'Semarang'),
('UMKM Lestari', 'Agus', 'Semarang'),
('UMKM Nusantara', 'Wawan', 'Semarang');
