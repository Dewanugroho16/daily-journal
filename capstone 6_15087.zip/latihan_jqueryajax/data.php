<?php
include 'koneksi.php';

$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

$query = mysqli_query($conn, "SELECT * FROM umkm LIMIT $start, $limit");
?>

<table>
<tr>
    <th>No</th>
    <th>Nama UMKM</th>
    <th>Pemilik</th>
    <th>Alamat</th>
</tr>

<?php
$no = $start + 1;
while ($row = mysqli_fetch_assoc($query)) {
?>
<tr>
    <td><?= $no++; ?></td>
    <td><?= $row['nama_umkm']; ?></td>
    <td><?= $row['pemilik']; ?></td>
    <td><?= $row['alamat']; ?></td>
</tr>
<?php } ?>
</table>

<div style="margin-top:10px;">
<?php
$total_data = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM umkm"));
$total_page = ceil($total_data / $limit);

for ($i = 1; $i <= $total_page; $i++) {
    $active = ($i == $page) ? "active" : "";
    echo "<a href='#' class='pagination $active' data-page='$i'>$i</a>";
}
?>
</div>
