<!DOCTYPE html>
<html>
<head>
    <title>Admin - Pagination AJAX</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <style>
    table {
        border-collapse: collapse;
        width: 100%;
        margin-top: 10px;
        font-family: Arial, sans-serif;
    }
    table th {
        background: #2c7be5;
        color: white;
        padding: 8px;
    }
    table td {
        padding: 8px;
        border: 1px solid #ddd;
    }
    .pagination {
        display: inline-block;
        padding: 6px 10px;
        margin: 3px;
        border: 1px solid #2c7be5;
        color: #2c7be5;
        text-decoration: none;
        border-radius: 4px;
        cursor: pointer;
    }
    .pagination:hover, .pagination.active {
        background: #2c7be5;
        color: white;
    }
    </style>
</head>
<body>

<h2>Data UMKM</h2>
<div id="data-ajax"></div>

<script>
$(document).ready(function(){
    loadData(1);
    function loadData(page){
        $.ajax({
            url: "data.php",
            type: "GET",
            data: { page: page },
            success: function(res){
                $("#data-ajax").html(res);
            }
        });
    }
    $(document).on("click", ".pagination", function(e){
        e.preventDefault();
        let page = $(this).data("page");
        loadData(page);
    });
});
</script>

</body>
</html>
